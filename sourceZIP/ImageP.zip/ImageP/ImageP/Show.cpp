#include "stdafx.h"
#include "Show.h"


CShow::CShow()
{
}


CShow::~CShow()
{
}
